-- AlterTable
ALTER TABLE "cliants" ADD COLUMN     "emp_id" TEXT,
ADD COLUMN     "emp_name" TEXT;
