-- AlterTable
ALTER TABLE "cliants" ALTER COLUMN "email" DROP NOT NULL;

-- AlterTable
ALTER TABLE "employees" ALTER COLUMN "email" DROP NOT NULL;

-- AlterTable
ALTER TABLE "users" ALTER COLUMN "email" DROP NOT NULL;
