-- AlterTable
ALTER TABLE "hall_room_posts" ADD COLUMN     "like" TEXT[],
ADD COLUMN     "view" TEXT[];
